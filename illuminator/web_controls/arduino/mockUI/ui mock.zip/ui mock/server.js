var http = require('http');
var fs = require('fs');
var url = require('url');
var index = fs.readFileSync('controller.html');

var buttonStatus11 = "no";
var buttonStatus31 = "no";
var buttonStatus12 = "no";
var buttonStatus22 = "no";
var buttonStatus32 = "no";
var buttonStatus13 = "no";
var buttonStatus23 = "no";

http.createServer(function(req,res){
  var myUrl = url.parse(req.url);
  if("/" == myUrl.pathname){
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(index);
  }
  if("/ajax_inputs" == myUrl.pathname){
    var q = {};
    myUrl.query.split("&").forEach(function(el){ 
      var s = el.split("=");
      q[s[0]] = s[1];
    });
    if(q.button11){ console.log('buttonStatus11'+q.button11);buttonStatus11=q.button11;}
    if(q.button31){ console.log('buttonStatus31'+q.button31);buttonStatus31=q.button31;}
    if(q.button12){ console.log('buttonStatus12'+q.button12);buttonStatus12=q.button12;}
    if(q.button22){ console.log('buttonStatus22'+q.button22);buttonStatus22=q.button22;}
    if(q.button32){ console.log('buttonStatus32'+q.button32);buttonStatus32=q.button32;}
    if(q.button13){ console.log('buttonStatus13'+q.button13);buttonStatus13=q.button13;}
    if(q.button23){ console.log('buttonStatus23'+q.button23);buttonStatus23=q.button23;}
    console.log(" - - - ");

    var response= '<xml>'+
      '<buttonStatus11>'+(q.button11==1? "on":buttonStatus11)+'</buttonStatus11>'+
      '<buttonStatus31>'+(q.button31==1? "on":buttonStatus31)+'</buttonStatus31>'+
      '<buttonStatus12>'+(q.button12==1? "on":buttonStatus12)+'</buttonStatus12>'+
      '<buttonStatus22>'+(q.button22==1? "on":buttonStatus22)+'</buttonStatus22>'+
      '<buttonStatus32>'+(q.button32==1? "on":buttonStatus32)+'</buttonStatus32>'+
      '<buttonStatus13>'+(q.button13==1? "on":buttonStatus13)+'</buttonStatus13>'+
      '<buttonStatus23>'+(q.button23==1? "on":buttonStatus23)+'</buttonStatus23>'+
      '</xml>';
    res.writeHead(200, {'Content-Type': 'text/xml'});

    res.end(response);
  }
}).listen(8080);
