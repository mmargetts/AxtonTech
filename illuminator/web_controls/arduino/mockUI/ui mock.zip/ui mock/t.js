_manualOff1 ='';
_button11   ='';
_button21   ='';
_button31   ='';
_dayNight1  ='';

_manualOff2 ='';
_button12   ='';
_button22   ='';
_button32   ='';
_dayNight2='';

_manualOff3 ='';
_button13   ='';
_button23   ='';
_button33   ='';
_dayNight3='';

function XMLToString(oXML) {   
  if (window.ActiveXObject) {     
    return oXML.xml;  //if IE 
  } else {     
  return (new XMLSerializer()).serializeToString(oXML);   
  } 
}
function GetArduinoIO()
{
  nocache = '&nocache=' + Math.random() * 1000000;

  var request = new XMLHttpRequest();
  request.onreadystatechange = function()
  {


    if (this.readyState == 4) {
      if(this.status == 200) {
        if (this.responseXML != null) {
          if(digitalRead(io_jumper_illuminator1)==0 || digitalRead(io_jumper_illuminator2) == 0 || digitalRead(io_jumper_illuminator3) == 0 ){
            document.getElementById('xlrSwitch').checked = (this.responseXML.getElementsByTagName('buttonStatus11')[0].childNodes[0].nodeValue === 'on'); 
          }

          if(digitalRead(io_jumper_illuminator2) == 0 || digitalRead(io_jumper_illuminator3) === 0 ){ 
            var range = 1;
            if (this.responseXML.getElementsByTagName('buttonStatus12')[0].childNodes[0].nodeValue === 'on') {range = 1}
            if (this.responseXML.getElementsByTagName('buttonStatus22')[0].childNodes[0].nodeValue === 'on') {range = 2}
            if (this.responseXML.getElementsByTagName('buttonStatus32')[0].childNodes[0].nodeValue === 'on') {range = 3}
            document.getElementById('angle1').className += range==1? angleWrappers[0].className+" choosen":angleWrappers[0].className.replace(/choosen/g, "");
            document.getElementById('angle2').className += range==2? angleWrappers[0].className+" choosen":angleWrappers[0].className.replace(/choosen/g, ""); 
            document.getElementById('angle3').className += range==3? angleWrappers[0].className+" choosen":angleWrappers[0].className.replace(/choosen/g, ""); 

          }

          if(digitalRead(io_jumper_illuminator3) == 0 ){

            if (this.responseXML.getElementsByTagName('buttonStatus13')[0].childNodes[0].nodeValue === 'on') {
              document.getElementById('irlight');
            }

            if (this.responseXML.getElementsByTagName('buttonStatus23')[0].childNodes[0].nodeValue === 'on') {
              document.getElementById('whiteLight');
            } 
          } 
        }
      }
    }
  }
  request.open('GET', 'http://192.168.0.81:3000/ajax_inputs?' + _manualOff1 + _manualOff2 + _manualOff3 + _dayNight1 + _dayNight2 + _dayNight3 + _button11 + _button21 + _button31 + _button12 + _button22 + _button32 + _button13 + _button23 + _button33 + nocache, true);
  request.send(null);
  setTimeout('GetArduinoIO()', 1000);

  _manualOff1 ='';
  _button11   ='';
  _button21   ='';
  _button31   ='';
  _dayNight1  ='';

  _manualOff2 ='';
  _button12   ='';
  _button22   ='';
  _button32   ='';
  _dayNight2='';

  _manualOff3 ='';
  _button13   ='';
  _button23   ='';
  _button33   ='';
  _dayNight3='';

}


function xlrButton(){
  _button11 = '&button11='+(this.checked? '1':'0');
  _button31 = '&button31='+(this.checked? '0':'1');
}

function angleButton(){
  _button12 = '&button12='+(this.id=='angle1'?'1':'0');
  _button22 = '&button22='+(this.id=='angle2'?'1':'0');
  _button32 = '&button32='+(this.id=='angle3'?'1':'0');
}

function hybridButton(){
  _button13 = '&button13='+(this.id=='irlight'?'1':'0');
  _button23 = '&button23='+(this.id=='whiteLight'?'1':'0');
}
